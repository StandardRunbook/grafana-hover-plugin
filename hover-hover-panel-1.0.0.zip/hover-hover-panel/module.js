define(["@grafana/data","react","@emotion/css","@grafana/ui","@grafana/runtime"],(e,t,o,a,n)=>(()=>{"use strict";var i={7:e=>{e.exports=a},89:e=>{e.exports=o},531:e=>{e.exports=n},781:t=>{t.exports=e},959:e=>{e.exports=t}},l={};function r(e){var t=l[e];if(void 0!==t)return t.exports;var o=l[e]={exports:{}};return i[e](o,o.exports,r),o.exports}r.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return r.d(t,{a:t}),t},r.d=(e,t)=>{for(var o in t)r.o(t,o)&&!r.o(e,o)&&Object.defineProperty(e,o,{enumerable:!0,get:t[o]})},r.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var s={};r.r(s),r.d(s,{plugin:()=>v});var d=r(781);function p(e,t,o,a,n,i,l){try{var r=e[i](l),s=r.value}catch(e){return void o(e)}r.done?t(s):Promise.resolve(s).then(a,n)}var c=r(959),g=r.n(c),u=r(89),m=r(7),x=r(531);const f=()=>({wrapper:u.css`
      position: relative;
      display: flex;
      flex-direction: column;
      height: 100%;
      overflow: hidden;
    `,header:u.css`
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 8px 16px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    `,title:u.css`
      margin: 0;
      font-size: 16px;
      font-weight: 500;
    `,count:u.css`
      font-size: 12px;
      opacity: 0.7;
    `,currentHoverWidget:u.css`
      display: flex;
      flex-direction: column;
      overflow: hidden;
      flex: 1;
      height: 100%;
    `,widgetHeader:u.css`
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(115, 191, 105, 0.3);
    `,widgetTitle:u.css`
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: rgba(115, 191, 105, 1);
    `,widgetLive:u.css`
      font-size: 10px;
      font-weight: 600;
      color: rgba(115, 191, 105, 1);
      animation: blink 1.5s ease-in-out infinite;

      @keyframes blink {
        0%,
        100% {
          opacity: 1;
        }
        50% {
          opacity: 0.4;
        }
      }
    `,widgetContent:u.css`
      display: flex;
      flex-direction: column;
      gap: 8px;
      flex: 1;
      min-height: 0;
    `,widgetCompactHeader:u.css`
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 4px 0;
      font-size: 11px;
      flex-wrap: wrap;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      padding-bottom: 6px;
      margin-bottom: 4px;
    `,widgetCompactPanel:u.css`
      font-weight: 600;
      color: rgba(255, 255, 255, 0.9);
    `,widgetCompactSeparator:u.css`
      color: rgba(255, 255, 255, 0.3);
    `,widgetCompactSeries:u.css`
      color: rgba(255, 255, 255, 0.7);
    `,widgetCompactValue:u.css`
      font-weight: 700;
      color: rgba(115, 191, 105, 1);
      font-family: "Roboto Mono", monospace;
    `,widgetCompactTime:u.css`
      color: rgba(255, 255, 255, 0.6);
      font-family: "Roboto Mono", monospace;
      font-size: 11px;
    `,widgetLoading:u.css`
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
      color: rgba(255, 255, 255, 0.5);
      font-style: italic;
    `,widgetMainValue:u.css`
      display: flex;
      flex-direction: column;
      gap: 4px;
    `,widgetSeriesName:u.css`
      font-size: 13px;
      font-weight: 600;
      color: rgba(255, 255, 255, 0.9);
      letter-spacing: 0.3px;
    `,widgetValue:u.css`
      font-size: 32px;
      font-weight: 700;
      color: rgba(115, 191, 105, 1);
      line-height: 1.2;
      font-family: "Roboto Mono", monospace;
    `,widgetMetadata:u.css`
      display: flex;
      flex-direction: column;
      gap: 6px;
      padding-top: 8px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
    `,widgetMetaRow:u.css`
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
    `,widgetMetaLabel:u.css`
      font-size: 11px;
      font-weight: 600;
      color: rgba(255, 255, 255, 0.6);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    `,widgetMetaValue:u.css`
      font-size: 12px;
      font-weight: 500;
      color: rgba(255, 255, 255, 0.9);
      text-align: right;
    `,noCurrentHover:u.css`
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 32px 16px;
      margin: 12px;
      background: rgba(255, 255, 255, 0.03);
      border: 2px dashed rgba(255, 255, 255, 0.1);
      border-radius: 8px;
      opacity: 0.6;
    `,noHoverIcon:u.css`
      font-size: 48px;
      margin-bottom: 12px;
      opacity: 0.5;
    `,noHoverText:u.css`
      font-size: 14px;
      color: rgba(255, 255, 255, 0.6);
      text-align: center;
    `,widgetLogsSection:u.css`
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
      padding-top: 8px;
    `,widgetLogsSectionHeader:u.css`
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: rgba(115, 191, 105, 0.8);
      margin-bottom: 8px;
    `,widgetLogsList:u.css`
      display: flex;
      flex-direction: column;
      gap: 6px;
      flex: 1;
      overflow-y: auto;
      padding-right: 4px;

      /* Custom scrollbar */
      &::-webkit-scrollbar {
        width: 6px;
      }
      &::-webkit-scrollbar-track {
        background: rgba(0, 0, 0, 0.2);
        border-radius: 3px;
      }
      &::-webkit-scrollbar-thumb {
        background: rgba(115, 191, 105, 0.4);
        border-radius: 3px;
      }
      &::-webkit-scrollbar-thumb:hover {
        background: rgba(115, 191, 105, 0.6);
      }
    `,widgetLogItem:u.css`
      display: flex;
      gap: 6px;
      align-items: flex-start;
      padding: 4px 6px;
      margin: 0;
      font-family: "Roboto Mono", "Courier New", monospace;
      font-size: 11px;
      line-height: 1.4;
      transition: all 0.15s ease;
      user-select: text;
      border-left: 2px solid transparent;

      &:hover {
        background: rgba(255, 255, 255, 0.03);
      }

      &[style*="cursor: pointer"] {
        &:hover {
          background: rgba(115, 191, 105, 0.08);
          border-left-color: rgba(115, 191, 105, 0.6);
        }
      }
    `,widgetLogToggle:u.css`
      color: rgba(115, 191, 105, 0.7);
      font-size: 9px;
      flex-shrink: 0;
      width: 12px;
      margin-top: 3px;
    `,widgetLogText:u.css`
      color: rgba(255, 255, 255, 0.85);
      word-break: break-word;
      flex: 1;
    `,widgetLogDivider:u.css`
      height: 1px;
      background: linear-gradient(
        to right,
        transparent,
        rgba(115, 191, 105, 0.3) 20%,
        rgba(115, 191, 105, 0.3) 80%,
        transparent
      );
      margin: 12px 0;
    `,eventList:u.css`
      flex: 1;
      overflow-y: auto;
      padding: 8px;
    `,event:u.css`
      margin-bottom: 8px;
      padding: 8px 12px;
      background: rgba(255, 255, 255, 0.05);
      border-radius: 4px;
      border-left: 3px solid rgba(115, 191, 105, 0.7);
      transition: all 0.2s ease;

      &:hover {
        background: rgba(255, 255, 255, 0.08);
        border-left-color: rgba(115, 191, 105, 1);
      }
    `,eventHeader:u.css`
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 4px;
    `,panelName:u.css`
      font-weight: 500;
      font-size: 14px;
    `,timestamp:u.css`
      font-size: 11px;
      opacity: 0.6;
    `,eventDetails:u.css`
      display: flex;
      flex-direction: column;
      gap: 8px;
      font-size: 12px;
      opacity: 0.9;
    `,detail:u.css`
      display: inline-block;
    `,metricInfo:u.css`
      display: flex;
      gap: 8px;
      align-items: flex-start;
    `,metricLabel:u.css`
      font-weight: 600;
      color: rgba(255, 255, 255, 0.7);
      min-width: 60px;
    `,metricValue:u.css`
      color: rgba(255, 255, 255, 0.9);
      word-break: break-word;
      flex: 1;
    `,noEvents:u.css`
      text-align: center;
      padding: 32px;
      opacity: 0.5;
    `,debugInfo:u.css`
      margin-top: 8px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding-top: 8px;
    `,debugSummary:u.css`
      cursor: pointer;
      font-size: 11px;
      color: rgba(255, 255, 255, 0.6);
      &:hover {
        color: rgba(255, 255, 255, 0.8);
      }
    `,debugPre:u.css`
      background: rgba(0, 0, 0, 0.3);
      padding: 8px;
      border-radius: 4px;
      font-size: 10px;
      overflow-x: auto;
      margin: 4px 0 0 0;
      max-height: 200px;
      overflow-y: auto;
    `,customTooltip:u.css`
      position: fixed;
      z-index: 9999;
      background: rgba(0, 0, 0, 0.9);
      color: white;
      padding: 12px;
      border-radius: 6px;
      border: 1px solid rgba(115, 191, 105, 0.7);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
      max-width: 300px;
      font-size: 12px;
      pointer-events: none;
      backdrop-filter: blur(4px);
    `,tooltipHeader:u.css`
      margin-bottom: 8px;
      padding-bottom: 6px;
      border-bottom: 1px solid rgba(115, 191, 105, 0.3);
      font-size: 14px;
      color: rgba(115, 191, 105, 1);
    `,tooltipContent:u.css`
      display: flex;
      flex-direction: column;
      gap: 4px;
    `,tooltipRow:u.css`
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 8px;
    `,tooltipLabel:u.css`
      font-weight: 600;
      color: rgba(255, 255, 255, 0.7);
      min-width: 50px;
      flex-shrink: 0;
    `,tooltipValue:u.css`
      color: rgba(255, 255, 255, 0.9);
      word-break: break-word;
      text-align: right;
      flex: 1;
    `,tooltipDivider:u.css`
      margin: 8px 0;
      height: 1px;
      background: rgba(115, 191, 105, 0.3);
    `,tooltipSection:u.css`
      margin-top: 8px;
    `,tooltipSectionHeader:u.css`
      font-weight: 600;
      color: rgba(115, 191, 105, 0.8);
      font-size: 11px;
      text-transform: uppercase;
      margin-bottom: 6px;
      letter-spacing: 0.5px;
    `,tooltipLoading:u.css`
      color: rgba(255, 255, 255, 0.6);
      font-style: italic;
      font-size: 11px;
    `,tooltipDataFrame:u.css`
      margin-bottom: 6px;
      padding-bottom: 4px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      &:last-child {
        border-bottom: none;
        margin-bottom: 0;
      }
    `,tooltipFields:u.css`
      margin-top: 4px;
    `,tooltipMuted:u.css`
      color: rgba(255, 255, 255, 0.5);
      font-size: 11px;
      font-style: italic;
    `}),v=new d.PanelPlugin(e=>{var t,o,a,n;const{options:i,width:l,height:r,id:s,eventBus:v}=e,b=(0,m.useStyles2)(f),[h,w]=(0,c.useState)(null),[y,I]=(0,c.useState)([]),[k,E]=(0,c.useState)(new Set),[L,S]=(0,c.useState)(!1),N=(0,c.useCallback)((e,t)=>{return(o=function*(){const o=i.apiEndpoint;if(console.log("🔍 sendToAPI called, endpoint:",o),o)try{var a,n,l;S(!0),I([]);const r=e.metricData,s=new Date,d=new Date(Date.now()-i.timeWindowMs),p=(null==r?void 0:r.seriesName)||(null==r?void 0:r.fieldName)||"Unknown Series",c=e.panelTitle||"Unknown Panel",g=null==t||null===(a=t._eventsOrigin)||void 0===a?void 0:a._state,u=(null==g?void 0:g.title)||"Unknown Dashboard",m={org:String((null===(l=x.config.bootData)||void 0===l||null===(n=l.user)||void 0===n?void 0:n.orgId)||1),dashboard:u,panel_title:c,metric_name:p,start_time:d.toISOString(),end_time:s.toISOString()};console.log("📤 Sending to API:",o),console.log("Payload:",m);const f={"Content-Type":"application/json"};i.apiKey&&(f.Authorization=`Bearer ${i.apiKey}`);const v=yield fetch(o,{method:"POST",headers:f,body:JSON.stringify(m)});if(!v.ok){const e=yield v.text();console.error("❌ API request failed:",v.status,v.statusText),console.error("Error response:",e);try{const t=JSON.parse(e);console.error("Error details:",t)}catch(e){}return}const b=yield v.json();if(b&&Array.isArray(b.log_groups)){const e=[],t=i.maxLogs,o=i.maxLogLength;let a=0;b.log_groups.forEach((n,i)=>{if(a>=t)return;const l=n.relative_change,r=l>0?"↑":l<0?"↓":"→",s=l>50?"🔴":l>10?"🟠":l<-10?"🟢":"⚪";e.push(`${s} ${r} ${l.toFixed(1)}% change from baseline`),a++,Array.isArray(n.representative_logs)&&n.representative_logs.forEach(n=>{if(a>=t)return;const i=n.length>o?n.substring(0,o)+"... [truncated]":n;e.push(`  ${i}`),a++})}),a>=t&&e.push(`... [${b.log_groups.length-e.length} more logs truncated for performance]`),console.log("📋 Setting API logs, count:",e.length),console.log("First few logs:",e.slice(0,3)),I(e),S(!1)}else console.warn("Unexpected API response format:",b),console.log("Full result:",b),I([]),S(!1)}catch(e){console.error("Error sending to API:",e),I([`Error: ${e}`]),S(!1)}else console.log("⚠️ No API endpoint configured, skipping")},function(){var e=this,t=arguments;return new Promise(function(a,n){var i=o.apply(e,t);function l(e){p(i,a,n,l,r,"next",e)}function r(e){p(i,a,n,l,r,"throw",e)}l(void 0)})})();var o},[i.apiEndpoint,i.apiKey,i.timeWindowMs,i.maxLogs,i.maxLogLength]);return(0,c.useEffect)(()=>{const e=(0,x.getAppEvents)(),t=null==v?void 0:v.getStream(d.DataHoverEvent).subscribe(e=>{var t,o,a,n,l,r,s,d,p;console.log("🎯 HOVER EVENT RECEIVED");const c=null==e?void 0:e.origin,g=null===(t=e.payload)||void 0===t?void 0:t.origin,u=e.payload,m=(null==u?void 0:u.point)||{},x=null==u?void 0:u.data;let f,v,b,h="Unknown Series",y="";if(x&&x.fields){var I,k,E;const e=null!==(E=null==u?void 0:u.columnIndex)&&void 0!==E?E:null==u?void 0:u.fieldIndex;var L;const t=null!==(L=null==u?void 0:u.rowIndex)&&void 0!==L?L:null==u?void 0:u.dataIndex;let o=e;if(void 0===o&&(o=x.fields.findIndex(e=>"time"!==e.type)),void 0!==o&&x.fields[o]){var S;const e=x.fields[o];y=e.name||"",h=(null===(S=e.config)||void 0===S?void 0:S.displayName)||e.name||x.name||"Unknown Series",void 0!==t&&e.values&&e.values.length>t&&(f=e.values[t],v=e.display?e.display(f).text:String(f))}void 0!==t&&(null===(k=x.fields[0])||void 0===k||null===(I=k.values)||void 0===I?void 0:I.length)>t&&(b=x.fields[0].values[t])}void 0===f&&void 0!==(null==m?void 0:m.value)&&(f=m.value),"Unknown Series"===h&&(null==u?void 0:u.dataId)&&(h=u.dataId);const T=null==x?void 0:x.refId;let P="Unknown Panel",_="unknown";var C,z;(null==c||null===(a=c._eventsOrigin)||void 0===a||null===(o=a._state)||void 0===o?void 0:o.title)?P=c._eventsOrigin._state.title:(null==c||null===(n=c._state)||void 0===n?void 0:n.title)?P=c._state.title:(null==g||null===(r=g._eventsOrigin)||void 0===r||null===(l=r._state)||void 0===l?void 0:l.title)?P=g._eventsOrigin._state.title:(null==g||null===(s=g._state)||void 0===s?void 0:s.title)?P=g._state.title:(null==x||null===(p=x.meta)||void 0===p||null===(d=p.custom)||void 0===d?void 0:d.title)?P=x.meta.custom.title:(null==x?void 0:x.name)?P=`Panel: ${x.name}`:T&&(P=`Query ${T}`),T?_=T:(null==c?void 0:c.panelId)?_=c.panelId:(null==g?void 0:g.panelId)&&(_=g.panelId);const D={panelId:_,panelTitle:P,timestamp:Date.now(),x:(null==m?void 0:m.time)||(null==m?void 0:m.x)||0,y:f||(null==m?void 0:m.y)||0,elementType:"data-hover",metricData:{seriesName:h,fieldName:y,value:f,formattedValue:v,time:b,fieldIndex:null!==(C=null==u?void 0:u.columnIndex)&&void 0!==C?C:null==u?void 0:u.fieldIndex,dataIndex:null!==(z=null==u?void 0:u.rowIndex)&&void 0!==z?z:null==u?void 0:u.dataIndex,point:m,dataFrame:x}};console.log("✅ Setting currentHover:",D.panelTitle),w(D),console.log("📡 Calling sendToAPI, endpoint:",i.apiEndpoint),N(D,c)}),o=e.subscribe(d.LegacyGraphHoverEvent,e=>{var t,o,a,n,i,l,r;const s={panelId:"legacy-graph-hover",panelTitle:"Legacy Graph Hover",timestamp:Date.now(),x:(null===(o=e.payload)||void 0===o||null===(t=o.pos)||void 0===t?void 0:t.x)||0,y:(null===(n=e.payload)||void 0===n||null===(a=n.pos)||void 0===a?void 0:a.y)||0,elementType:"legacy-graph-hover",metricData:{seriesName:(null===(l=e.payload)||void 0===l||null===(i=l.series)||void 0===i?void 0:i.name)||"Legacy Series",value:null===(r=e.payload)||void 0===r?void 0:r.value}};w(s),N(s)});return()=>{null==t||t.unsubscribe(),null==o||o.unsubscribe()}},[s,N,v]),g().createElement(g().Fragment,null,g().createElement("div",{className:(0,u.cx)(b.wrapper),style:{width:l,height:r}},h&&g().createElement("div",{className:b.currentHoverWidget},g().createElement("div",{className:b.widgetContent},g().createElement("div",{className:b.widgetCompactHeader},(null===(t=h.metricData)||void 0===t?void 0:t.time)&&g().createElement(g().Fragment,null,g().createElement("span",{className:b.widgetCompactTime},(0,d.dateTime)(h.metricData.time).format("YYYY-MM-DD HH:mm:ss")),g().createElement("span",{className:b.widgetCompactSeparator},"•")),g().createElement("span",{className:b.widgetCompactPanel},h.panelTitle),g().createElement("span",{className:b.widgetCompactSeparator},"•"),g().createElement("span",{className:b.widgetCompactSeries},(null===(o=h.metricData)||void 0===o?void 0:o.seriesName)||"No Series"),g().createElement("span",{className:b.widgetCompactSeparator},"•"),g().createElement("span",{className:b.widgetCompactValue},(null===(a=h.metricData)||void 0===a?void 0:a.formattedValue)||(null===(n=h.metricData)||void 0===n?void 0:n.value)||"—")),L?g().createElement("div",{className:b.widgetLoading},"Loading logs..."):y.length>0?g().createElement("div",{className:b.widgetLogsSection},g().createElement("div",{className:b.widgetLogsList},y.map((e,t)=>{const o=k.has(t),a=i.logTruncateLength,n=e.length>a;return g().createElement("div",{key:t,className:b.widgetLogItem,onClick:()=>n&&(e=>{E(t=>{const o=new Set(t);return o.has(e)?o.delete(e):o.add(e),o})})(t),style:{cursor:n?"pointer":"default"},title:n?"Click to expand/collapse":void 0},n&&g().createElement("span",{className:b.widgetLogToggle},o?"▼":"▶"),g().createElement("span",{className:b.widgetLogText},o||!n?e:e.substring(0,a)+"... (click to expand)"))}))):g().createElement("div",{className:b.widgetLoading},"No logs found"))),!h&&g().createElement("div",{className:b.noCurrentHover},g().createElement("div",{className:b.noHoverIcon},"👆"),g().createElement("div",{className:b.noHoverText},"Hover over a panel to see live data"))))}).setPanelOptions(e=>((e=>{e.addTextInput({path:"apiEndpoint",name:"API Endpoint",description:"URL endpoint to send hover data for log queries",defaultValue:"http://127.0.0.1:3001/query_logs"}).addTextInput({path:"apiKey",name:"API Key",description:"Optional API key for authenticating requests to your log analysis API",defaultValue:"",settings:{placeholder:"Enter your API key (optional)"}}).addNumberInput({path:"timeWindowMs",name:"Time Window (ms)",description:"Time window for log queries in milliseconds (default: 1 hour)",defaultValue:36e5,settings:{min:1e3,step:1e3}}).addNumberInput({path:"maxLogs",name:"Max Logs",description:"Maximum number of log entries to display",defaultValue:500,settings:{min:1,step:1}}).addNumberInput({path:"maxLogLength",name:"Max Log Length",description:"Maximum length of individual log entry",defaultValue:1e4,settings:{min:100,step:100}}).addNumberInput({path:"logTruncateLength",name:"Log Truncate Length",description:"Character count threshold for expandable logs",defaultValue:120,settings:{min:50,step:10}})})(e),e));return s})());